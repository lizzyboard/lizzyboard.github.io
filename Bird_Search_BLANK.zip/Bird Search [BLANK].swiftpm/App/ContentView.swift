import SwiftUI

struct ContentView: View {
    @State var isSinging = false
    @State var birdColor = Color.indigo
    
    var body: some View {
        VStack {
            Image("title")
                .resizable().aspectRatio(contentMode: .fit)

            ZStack(alignment: .center) {
                // Set bird colors
                Image("face")
                    .renderingMode(.template)
                    .resizable().aspectRatio(contentMode: .fit)
                    .foregroundColor(birdColor)

                Image("body")
                    .renderingMode(.template)
                    .resizable().aspectRatio(contentMode: .fit)
                    .foregroundColor(birdColor)

                // Draw bird outline
                Image("blank")
                    .resizable().aspectRatio(contentMode: .fit)

                // Draw bird's face
                if isSinging {
                    Image("beak_singing")
                        .resizable().aspectRatio(contentMode: .fit)
                } else {
                    Image("beak_closed")
                        .resizable().aspectRatio(contentMode: .fit)
                }
                
                // Add bird's accessories
                
            }
            
            Button {
                // Random bird button 

            } label: {
                Image("new_bird_button")
                    .resizable().frame(width: 280, height: 40)
            }

            Button {
                // Random season button

            } label: {
                Image("new_season_button")
                    .resizable().frame(width: 280, height: 40)
            }
            
        }
    }
}
