import SwiftUI

struct ContentView: View {
    @State var isSinging = false
    @State var birdColor = Color.indigo
    
    let seasons = ["spring", "summer", "autumn", "winter"]
    @State var season = ""
    
    func randomColor() -> Color {
        let red = Double.random(in: 0..<1)
        let green = Double.random(in: 0..<1)
        let blue = Double.random(in: 0..<1)
        
        return Color(.sRGB, red: red, green: green, blue: blue, opacity: 1.0)
    }
    
    var body: some View {
        VStack {
            Image("title")
                .resizable().aspectRatio(contentMode: .fit)

            ZStack(alignment: .center) {
                // Set bird colors
                Image("face")
                    .renderingMode(.template)
                    .resizable().aspectRatio(contentMode: .fit)
                    .foregroundColor(birdColor)

                Image("body")
                    .renderingMode(.template)
                    .resizable().aspectRatio(contentMode: .fit)
                    .foregroundColor(birdColor)

                // Draw bird outline
                Image("blank")
                    .resizable().aspectRatio(contentMode: .fit)

                // Draw bird's face
                if isSinging {
                    Image("beak_singing")
                        .resizable().aspectRatio(contentMode: .fit)
                } else {
                    Image("beak_closed")
                        .resizable().aspectRatio(contentMode: .fit)
                }
                
                // Add bird's accessories
                Image(season)
                    .resizable().aspectRatio(contentMode: .fit)
            }
            
            Button {
                // Random bird button 
                isSinging = Bool.random()
                birdColor = randomColor()
            } label: {
                Image("new_bird_button")
                    .resizable().frame(width: 280, height: 40)
            }

            Button {
                // Random season button
                season = seasons.randomElement()!
            } label: {
                Image("new_season_button")
                    .resizable().frame(width: 280, height: 40)
            }
            
            Button {
                 // Reset button
                isSinging = false
                birdColor = Color.indigo
                season = ""
            } label: {
                Image("reset_button")
                    .resizable().frame(width: 90, height: 30)
            }
        }
    }
}
